from sympy import *
import math
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d,Axes3D
import rclpy
import math
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
from std_msgs.msg import Bool
from std_srvs.srv import SetBool
from geometry_msgs.msg import PoseStamped
import time

xom=[]
yom=[]
zom=[]

class Sub(Node):

    def __init__(self):
        
        super().__init__('control_publisher')
        
        self.joint_position_pub = self.create_publisher(Float64MultiArray, '/position_controller/commands', 50)
        self.odom_sub=self.create_subscription(PoseStamped,'/odom',self.odom_callback, 10)
        
        
        self.theta_1 = symbols("theta_1")   
        self.theta_2 = symbols("theta_2")   
        self.theta_3 = symbols("theta_3")   
        self.theta_4 = symbols("theta_4")
        self.theta_5 = symbols("theta_5")   
        self.theta_6 = symbols("theta_6")

        ## Defining transformation matrices

        self.t1 = Matrix([[0,0,1,0],[-1,0,0,0],[0,-1,0,295],[0,0,0,1]])
        self.t2 = Matrix([[1,0,0,0],[0,0,-1,0],[0,1,0,44.02],[0,0,0,1]])
        self.t3 = Matrix([[1,0,0,0],[0,1,0,0],[0,0,1,124.5],[0,0,0,1]])
        self.t4 = Matrix([[cos(self.theta_1),0,-sin(self.theta_1),0],[sin(self.theta_1),0,cos(self.theta_1),0],[0,-1,0,362],[0,0,0,1]])
        self.t5 = Matrix([[0,0,1,0],[-1,0,0,0],[0,-1,0,150],[0,0,0,1]])
        self.t6 = Matrix([[sin(self.theta_2),0,cos(self.theta_2),0],[-cos(self.theta_2),0,sin(self.theta_2),0],[0,-1,0,0],[0,0,0,1]])
        self.t7 = Matrix([[1,0,0,0],[0,0,-1,0],[0,1,0,700],[0,0,0,1]])
        self.t8 = Matrix([[-sin(self.theta_3),0,cos(self.theta_3),0],[cos(self.theta_3),0,sin(self.theta_3),0],[0,1,0,0],[0,0,0,1]])
        self.t9 = Matrix([[0,-1,0,0],[1,0,0,0],[0,0,1,314+286],[0,0,0,1]])
        self.t10 = Matrix([[sin(self.theta_4),0,cos(self.theta_4),0],[-cos(self.theta_4),0,sin(self.theta_4),0],[0,-1,0,0],[0,0,0,1]])
        self.t11 = Matrix([[cos(self.theta_5),0,sin(self.theta_5),0],[sin(self.theta_5),0,-cos(self.theta_5),0],[0,1,0,0],[0,0,0,1]])
        self.t12 = Matrix([[1,0,0,0],[0,1,0,0],[0,0,1,65],[0,0,0,1]])
        self.t13 = Matrix([[cos(self.theta_6),-sin(self.theta_6),0,0],[sin(self.theta_6),cos(self.theta_6),0,0],[0,0,1,0],[0,0,0,1]])

        self.T=self.t1*self.t2*self.t3*self.t4*self.t5*self.t6*self.t7*self.t8*self.t9*self.t10*self.t11*self.t12*self.t13
        self.TI=self.T.subs([(self.theta_1, 0), (self.theta_2, 0), (self.theta_3, 0), (self.theta_4, 0), (self.theta_5, 0), (self.theta_6, 0)])  


        self.T1=self.t1*self.t2*self.t3*self.t4
        self.T2=self.t1*self.t2*self.t3*self.t4*self.t5*self.t6*self.t7
        self.T3=self.t1*self.t2*self.t3*self.t4*self.t5*self.t6*self.t7*self.t8*self.t9


        ## Obtaining Column Matrices Z

        self.Z1=expand(self.T1[0:3,2])
        self.Z2=expand(self.T2[0:3,2])
        self.Z3=expand(self.T3[0:3,2])

        ## Obtaining Row Matrix P

        self.P=expand(self.T3[0:3,3])

        ## Obtaining partial derivate of P wrt different joint angles 

        self.p1=expand(diff(self.P,self.theta_1))
        self.p2=expand(diff(self.P,self.theta_2))
        self.p3=expand(diff(self.P,self.theta_3))


        ## Obtaining Jac)obian Matrix J

        self.J1=Matrix.hstack(self.p1,self.p2,self.p3)
        self.J2=Matrix.hstack(self.Z1,self.Z2,self.Z3)
        self.J=expand(Matrix.vstack(self.J1,self.J2))

        self.the1=(0.0001)
        self.the2=(-0.0001)
        self.the3=(0.0001)
        self.the4=(-0.00000001)
        self.the5=(0.000000001)
        self.the6=(-0.000000001)
        self.dt=0.1
        self.T1=20
        self.t=0
        self.i=True
        self.j=0
        self.inp=0
        self.msg2 = Float64MultiArray()
        self.timer = self.create_timer(self.dt, self.timer_callback)
    
    def odom_callback(self,msg):
        xo=msg.pose.position.x
        yo=msg.pose.position.y
        zo=msg.pose.position.z
        xom.append(xo)
        yom.append(yo)
        zom.append(zo)
        
    
    def timer_callback(self):
        
        def ori(self):
            TP=self.T3.subs([(self.theta_1,self.the1),(self.theta_2,self.the2),(self.theta_3,self.the3)])
            TD=Matrix([[0,0,1],[0,-1,0],[1,0,0]])
            TO=Transpose(TP[0:3,0:3])*TD
            self.the5=acos(TO[2,2])
            self.the4=-atan(TO[0,2]/TO[1,2])
            self.the6=-atan(TO[2,1]/TO[2,0])        
        
        
        def invk(self,xd,yd,zd,phid,thetad,psid):
            #Computing Joint Velocities
            X_dot = Matrix([[xd],[yd],[zd],[phid],[thetad],[psid]])
            JS=self.J.subs([(self.theta_1,self.the1),(self.theta_2,self.the2),(self.theta_3,self.the3)])
            Q_dot = JS.pinv() * X_dot
            q1_dot=Q_dot[0,0]
            q2_dot=Q_dot[1,0]
            q3_dot=Q_dot[2,0]

            
            #Computing Joint Angle 
            
            q1=self.the1+(q1_dot*self.dt)
            q2=self.the2+(q2_dot*self.dt)
            q3=self.the3+(q3_dot*self.dt)

            self.the1=q1
            self.the2=q2
            self.the3=q3

            
            # Function call to determine q4,q5 and q6 values
            ori(self)
            
            # Publishing joint angle values
            self.msg2 = Float64MultiArray(data=[-self.the1,-self.the2,-self.the3,-self.the4,-self.the5,-self.the6])         
            print("Publishing Joint Angles Position: ",self.msg2.data) 
            self.joint_position_pub.publish(self.msg2)

            self.t=self.t+self.dt
        
        if self.t<=20:
            X_dot = Matrix([[20],[0],[-30],[0],[0],[0]])
            invk(self,X_dot[0,0],X_dot[1,0],X_dot[2,0],X_dot[3,0],X_dot[4,0],X_dot[5,0])
        else:

            figure,axis = plt.subplots() 
            plt.plot(xom,zom,color='b')
            axis.set_title("Trajectory of the gripper for Validation")
            axis.set_xlabel("X Axis")
            axis.set_ylabel("Z Axis")
            plt.show()
            exit()
                       
    


def main(args=None):

    rclpy.init(args=args)

    control_pub = Sub()                       

    rclpy.spin(control_pub)

    control_pub.destroy_node()

    rclpy.shutdown()


if __name__ == '__main__':
    main()

