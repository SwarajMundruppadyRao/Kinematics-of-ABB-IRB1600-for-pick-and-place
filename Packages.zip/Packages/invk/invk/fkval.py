from sympy import *
import math
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d,Axes3D
import rclpy
import math
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
from std_msgs.msg import Bool
from std_srvs.srv import SetBool
from geometry_msgs.msg import PoseStamped
import time

xom=[]
yom=[]
zom=[]

class Sub(Node):

    def __init__(self):
        
        super().__init__('control_publisher')
        
        self.joint_position_pub = self.create_publisher(Float64MultiArray, '/position_controller/commands', 50)
        self.odom_sub=self.create_subscription(PoseStamped,'/odom',self.odom_callback, 10)
        
        
        self.theta_1 = symbols("theta_1")   
        self.theta_2 = symbols("theta_2")   
        self.theta_3 = symbols("theta_3")   
        self.theta_4 = symbols("theta_4")
        self.theta_5 = symbols("theta_5")   
        self.theta_6 = symbols("theta_6")

        ## Defining transformation matrices

        self.t1 = Matrix([[0,0,1,0],[-1,0,0,0],[0,-1,0,295],[0,0,0,1]])
        self.t2 = Matrix([[1,0,0,0],[0,0,-1,0],[0,1,0,44.02],[0,0,0,1]])
        self.t3 = Matrix([[1,0,0,0],[0,1,0,0],[0,0,1,124.5],[0,0,0,1]])
        self.t4 = Matrix([[cos(self.theta_1),0,-sin(self.theta_1),0],[sin(self.theta_1),0,cos(self.theta_1),0],[0,-1,0,362],[0,0,0,1]])
        self.t5 = Matrix([[0,0,1,0],[-1,0,0,0],[0,-1,0,150],[0,0,0,1]])
        self.t6 = Matrix([[sin(self.theta_2),0,cos(self.theta_2),0],[-cos(self.theta_2),0,sin(self.theta_2),0],[0,-1,0,0],[0,0,0,1]])
        self.t7 = Matrix([[1,0,0,0],[0,0,-1,0],[0,1,0,700],[0,0,0,1]])
        self.t8 = Matrix([[-sin(self.theta_3),0,cos(self.theta_3),0],[cos(self.theta_3),0,sin(self.theta_3),0],[0,1,0,0],[0,0,0,1]])
        self.t9 = Matrix([[0,-1,0,0],[1,0,0,0],[0,0,1,314+286],[0,0,0,1]])
        self.t10 = Matrix([[sin(self.theta_4),0,cos(self.theta_4),0],[-cos(self.theta_4),0,sin(self.theta_4),0],[0,-1,0,0],[0,0,0,1]])
        self.t11 = Matrix([[cos(self.theta_5),0,sin(self.theta_5),0],[sin(self.theta_5),0,-cos(self.theta_5),0],[0,1,0,0],[0,0,0,1]])
        self.t12 = Matrix([[1,0,0,0],[0,1,0,0],[0,0,1,65],[0,0,0,1]])
        self.t13 = Matrix([[cos(self.theta_6),-sin(self.theta_6),0,0],[sin(self.theta_6),cos(self.theta_6),0,0],[0,0,1,0],[0,0,0,1]])

        self.T=self.t1*self.t2*self.t3*self.t4*self.t5*self.t6*self.t7*self.t8*self.t9*self.t10*self.t11*self.t12*self.t13
        
        #Define values for desired joint angle rotations
        self.the1=0
        self.the2=0
        self.the3=0
        self.the4=0
        self.the5=0
        self.the6=0
        
        
        self.msg2 = Float64MultiArray()
        self.msg2 = Float64MultiArray(data=[-self.the1,-self.the2,-self.the3,-self.the4,-self.the5,-self.the6])         
        print("Publishing Joint Angles Position: ",self.msg2.data) 
        self.joint_position_pub.publish(self.msg2) 
        
    def odom_callback(self,msg):
        xo=msg.pose.position.x
        yo=msg.pose.position.y
        zo=msg.pose.position.z
        xom.append(xo)
        yom.append(yo)
        zom.append(zo)

    


def main(args=None):

    rclpy.init(args=args)

    control_pub = Sub()                       

    rclpy.spin(control_pub)

    control_pub.destroy_node()

    rclpy.shutdown()


if __name__ == '__main__':
    main()

