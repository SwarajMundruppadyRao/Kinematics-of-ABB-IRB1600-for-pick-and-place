from sympy import *
import math
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d,Axes3D
import rclpy
import math
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
from std_msgs.msg import Bool
from std_srvs.srv import SetBool
from geometry_msgs.msg import PoseStamped
import time


class Sub(Node):

    def __init__(self):
        
        super().__init__('control_publisher')
        
        self.joint_position_pub = self.create_publisher(Float64MultiArray, '/position_controller/commands', 50)
        
        self.theta_1 = symbols("theta_1")   
        self.theta_2 = symbols("theta_2")   
        self.theta_3 = symbols("theta_3")   
        self.theta_4 = symbols("theta_4")
        self.theta_5 = symbols("theta_5")   
        self.theta_6 = symbols("theta_6")

        ## Defining transformation matrices

        self.t1 = Matrix([[0,0,1,0],[-1,0,0,0],[0,-1,0,295],[0,0,0,1]])
        self.t2 = Matrix([[1,0,0,0],[0,0,-1,0],[0,1,0,44.02],[0,0,0,1]])
        self.t3 = Matrix([[1,0,0,0],[0,1,0,0],[0,0,1,124.5],[0,0,0,1]])
        self.t4 = Matrix([[cos(self.theta_1),0,-sin(self.theta_1),0],[sin(self.theta_1),0,cos(self.theta_1),0],[0,-1,0,362],[0,0,0,1]])
        self.t5 = Matrix([[0,0,1,0],[-1,0,0,0],[0,-1,0,150],[0,0,0,1]])
        self.t6 = Matrix([[sin(self.theta_2),0,cos(self.theta_2),0],[-cos(self.theta_2),0,sin(self.theta_2),0],[0,-1,0,0],[0,0,0,1]])
        self.t7 = Matrix([[1,0,0,0],[0,0,-1,0],[0,1,0,700],[0,0,0,1]])
        self.t8 = Matrix([[-sin(self.theta_3),0,cos(self.theta_3),0],[cos(self.theta_3),0,sin(self.theta_3),0],[0,1,0,0],[0,0,0,1]])
        self.t9 = Matrix([[0,-1,0,0],[1,0,0,0],[0,0,1,314+286],[0,0,0,1]])
        self.t10 = Matrix([[sin(self.theta_4),0,cos(self.theta_4),0],[-cos(self.theta_4),0,sin(self.theta_4),0],[0,-1,0,0],[0,0,0,1]])
        self.t11 = Matrix([[cos(self.theta_5),0,sin(self.theta_5),0],[sin(self.theta_5),0,-cos(self.theta_5),0],[0,1,0,0],[0,0,0,1]])
        self.t12 = Matrix([[1,0,0,0],[0,1,0,0],[0,0,1,65],[0,0,0,1]])
        self.t13 = Matrix([[cos(self.theta_6),-sin(self.theta_6),0,0],[sin(self.theta_6),cos(self.theta_6),0,0],[0,0,1,0],[0,0,0,1]])

        self.T=self.t1*self.t2*self.t3*self.t4*self.t5*self.t6*self.t7*self.t8*self.t9*self.t10*self.t11*self.t12*self.t13
        self.TI=self.T.subs([(self.theta_1, 0), (self.theta_2, 0), (self.theta_3, 0), (self.theta_4, 0), (self.theta_5, 0), (self.theta_6, 0)])  


        self.T1=self.t1*self.t2*self.t3*self.t4
        self.T2=self.t1*self.t2*self.t3*self.t4*self.t5*self.t6*self.t7
        self.T3=self.t1*self.t2*self.t3*self.t4*self.t5*self.t6*self.t7*self.t8*self.t9


        ## Obtaining Column Matrices Z

        self.Z1=expand(self.T1[0:3,2])
        self.Z2=expand(self.T2[0:3,2])
        self.Z3=expand(self.T3[0:3,2])


        ## Obtaining Row Matrix P

        self.P=expand(self.T3[0:3,3])

        ## Obtaining partial derivate of P wrt different joint angles 

        self.p1=expand(diff(self.P,self.theta_1))
        self.p2=expand(diff(self.P,self.theta_2))
        self.p3=expand(diff(self.P,self.theta_3))


        ## Obtaining Jac)obian Matrix J

        self.J1=Matrix.hstack(self.p1,self.p2,self.p3)
        self.J2=Matrix.hstack(self.Z1,self.Z2,self.Z3)
        self.J=expand(Matrix.vstack(self.J1,self.J2))

        self.the1=(0.0001)
        self.the2=(-0.0001)
        self.the3=(0.0001)
        self.dt=0.1
        self.T1=105
        self.t=0
        self.i=True
        self.j=0
        self.inp=0
        self.msg2 = Float64MultiArray()
        # self.inp=0
        self.timer = self.create_timer(self.dt, self.timer_callback)
            # Loop to get trajectory values
    

   
    def timer_callback(self):
        
        def ori(self):
            TP=self.T3.subs([(self.theta_1,self.the1),(self.theta_2,self.the2),(self.theta_3,self.the3)])
            # print("tp",TP)
            TD=Matrix([[1,0,0],[0,1,0],[0,0,-1]])
            TO=Transpose(TP[0:3,0:3])*TD
            # print("to",TO)
            self.the5=acos(TO[2,2])
            self.the4=-atan(TO[0,2]/TO[1,2])
            self.the6=-atan(TO[2,1]/TO[2,0])        
        
        
        def invk(self,xd,yd,zd,phid,thetad,psid):
                #Computing Joint Velocities
            X_dot = Matrix([[xd],[yd],[zd],[phid],[thetad],[psid]])
            JS=self.J.subs([(self.theta_1,self.the1),(self.theta_2,self.the2),(self.theta_3,self.the3)])
            Q_dot = JS.pinv() * X_dot
            q1_dot=Q_dot[0,0]
            q2_dot=Q_dot[1,0]
            q3_dot=Q_dot[2,0]

            
            #Computing Joint Angle 
            
            q1=self.the1+(q1_dot*self.dt)
            q2=self.the2+(q2_dot*self.dt)
            q3=self.the3+(q3_dot*self.dt)


            self.the1=q1
            self.the2=q2
            self.the3=q3
            ori(self)
            self.msg2 = Float64MultiArray(data=[-self.the1,-self.the2,-self.the3,self.the4,self.the5,self.the6])               
            print("Publishing Joint Angles Position: ",self.msg2.data) 
            self.joint_position_pub.publish(self.msg2) 

            
            self.t=self.t+self.dt
        
    
                
            # Computing velocity trajectory 
            
        if self.t<=20:
            X_dot = Matrix([[(((-795.90*math.pi)/40)*sin((math.pi*(self.t))/40))],[(((-795.90*math.pi)/40)*cos((math.pi*(self.t))/40))],[0],[0],[0],[0]])
            invk(self,X_dot[0,0],X_dot[1,0],X_dot[2,0],X_dot[3,0],X_dot[4,0],X_dot[5,0])   
             
        if self.t>20 and self.t<=40:

            X_dot = Matrix([[0],[-22],[-11.5],[0],[0],[0]])
            invk(self,X_dot[0,0],X_dot[1,0],X_dot[2,0],X_dot[3,0],X_dot[4,0],X_dot[5,0])
            
        if self.t>40 and self.t<=45:

            self.t=self.t+self.dt
        
        if self.t>45 and self.t<=65:

            X_dot = Matrix([[0],[22],[11.5],[0],[0],[0]])
            invk(self,X_dot[0,0],X_dot[1,0],X_dot[2,0],X_dot[3,0],X_dot[4,0],X_dot[5,0])  
            
        if self.t>65 and self.t<=70:
            self.t=self.t+self.dt
        
        
        if self.t>70 and self.t<=90:
            X_dot = Matrix([[(((795.90*math.pi)/40)*cos(((math.pi*(self.t-70))/40)))],[(((795.90*math.pi)/40)*sin(((math.pi*(self.t-70))/40)))],[0],[0],[0],[0]])
            invk(self,X_dot[0,0],X_dot[1,0],X_dot[2,0],X_dot[3,0],X_dot[4,0],X_dot[5,0])
            
        if self.t>90 and self.t<=95:
            self.t=self.t+self.dt
                     
        if self.t>95 and self.t<=115:

            X_dot = Matrix([[30],[0],[-13],[0],[0],[0]])
            invk(self,X_dot[0,0],X_dot[1,0],X_dot[2,0],X_dot[3,0],X_dot[4,0],X_dot[5,0])
            
        if self.t>115 and self.t<=120:
            self.t=self.t+self.dt
                        
        if self.t>120 and self.t<=140:

            X_dot = Matrix([[-30],[0],[13],[0],[0],[0]])
            invk(self,X_dot[0,0],X_dot[1,0],X_dot[2,0],X_dot[3,0],X_dot[4,0],X_dot[5,0])       
            
        if self.t>140 and self.t<=145:
            self.t=self.t+self.dt
                     
        if self.t>145 and self.t<=165:

            X_dot = Matrix([[30],[0],[-13],[0],[0],[0]])
            invk(self,X_dot[0,0],X_dot[1,0],X_dot[2,0],X_dot[3,0],X_dot[4,0],X_dot[5,0])
            
        if self.t>165 and self.t<=170:
            self.t=self.t+self.dt
                        
        if self.t>170 and self.t<=190:

            X_dot = Matrix([[-30],[0],[13],[0],[0],[0]])
            invk(self,X_dot[0,0],X_dot[1,0],X_dot[2,0],X_dot[3,0],X_dot[4,0],X_dot[5,0])      

        if self.t>190 and self.t<=195:
            self.t=self.t+self.dt
            
        if self.t>195 and self.t<=215:
            X_dot = Matrix([[(((-795.90*math.pi)/40)*sin((math.pi*(self.t-195))/40))],[(((795.90*math.pi)/40)*cos((math.pi*(self.t-195))/40))],[0],[0],[0],[0]])
            invk(self,X_dot[0,0],X_dot[1,0],X_dot[2,0],X_dot[3,0],X_dot[4,0],X_dot[5,0])                           
            
        if self.t>215 and self.t<=220:
            self.t=self.t+self.dt            
            
        if self.t>220 and self.t<=240:

            X_dot = Matrix([[0],[22],[-11.5],[0],[0],[0]])
            invk(self,X_dot[0,0],X_dot[1,0],X_dot[2,0],X_dot[3,0],X_dot[4,0],X_dot[5,0])
            
        if self.t>240 and self.t<=245:

            self.t=self.t+self.dt
        
        if self.t>245 and self.t<=265:
            X_dot = Matrix([[0],[-22],[11.5],[0],[0],[0]])
            invk(self,X_dot[0,0],X_dot[1,0],X_dot[2,0],X_dot[3,0],X_dot[4,0],X_dot[5,0])  
            
        if self.t>265 and self.t<=270:
            self.t=self.t+self.dt    

        if self.t>270 and self.t<=290:
            X_dot = Matrix([[(((795.90*math.pi)/40)*cos(((math.pi*(self.t-270))/40)))],[(((-795.90*math.pi)/40)*sin(((math.pi*(self.t-270))/40)))],[0],[0],[0],[0]])
            invk(self,X_dot[0,0],X_dot[1,0],X_dot[2,0],X_dot[3,0],X_dot[4,0],X_dot[5,0])             
    


def main(args=None):

    rclpy.init(args=args)

    control_pub = Sub()                       

    rclpy.spin(control_pub)

    control_pub.destroy_node()

    rclpy.shutdown()


if __name__ == '__main__':
    main()

